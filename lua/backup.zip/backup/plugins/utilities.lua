return {
	{
		"folke/todo-comments.nvim",
		event = "VimEnter",
		dependencies = { "nvim-lua/plenary.nvim" },
		opts = { signs = false },
	},
	{
		"andweeb/presence.nvim",
		lazy = false,
	},
	{
		"NvChad/nvim-colorizer.lua",
		config = function()
			require("colorizer").setup({})
		end,
	},
	{
		"MeanderingProgrammer/render-markdown.nvim",
		dependencies = { "nvim-treesitter/nvim-treesitter", "nvim-tree/nvim-web-devicons" },

		config = function()
			require("render-markdown").setup({
				indent = {
					enabled = true,
					per_level = 2,
				},
				bullet = {
					left_pad = 4,
				},
			})
		end,
	},
}

return {
    {
        "christoomey/vim-tmux-navigator",
        lazy = false,
    },
}

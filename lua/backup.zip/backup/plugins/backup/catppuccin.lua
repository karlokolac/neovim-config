return {
	{
		"catppuccin/nvim",
		name = "catppuccin",
		priority = 1000,
		init = function()
			vim.cmd.colorscheme("catppuccin")
		end,
		config = function()
			require("catppuccin").setup({
				flavour = "latte",
				integrations = {
					cmp = true,
					gitsigns = true,
					neotree = true,
					treesitter = true,
					notify = true,
				},
				no_italic = true,
				-- color_overrides = {
				-- 	all = {
				-- 		base = "#1d1d1d",
				-- 		mantle = "#1d1d1d",
				-- 		crust = "#1d1d1d",
				-- 		surface0 = "#303030",
				-- 	},
				-- },
			})
		end,
	},
}

return {
	{
		"nvim-telescope/telescope.nvim",
		dependencies = {
			"nvim-lua/plenary.nvim",
			"nvim-telescope/telescope-ui-select.nvim",
			{
				"nvim-tree/nvim-web-devicons",
				enabled = vim.g.have_nerd_font,
			},
		},

		config = function()
			require("telescope").setup({
				defaults = {
					file_ignore_patterns = { "^node/modules", "^%.git/", "^%.git$", ".DS_Store" },
					prompt_prefix = "   ",
					selection_caret = "  ",
					layout_strategy = "flex",
					layout_config = {
						horizontal = {
							prompt_position = "top",
						},
					},
					sorting_strategy = "ascending",
					border = true,
					borderchars = { " ", " ", " ", " ", " ", " ", " ", " " },
					color_devicons = true,
					pickers = {
						find_files = {
							hidden = true,
						},
					},
				},
				extensions = {
					["ui-select"] = {
						require("telescope.themes").get_dropdown({}),
					},
				},
			})
			require("telescope").load_extension("ui-select")
		end,
	},
}

return {
	"rebelot/kanagawa.nvim",
	priority = 1000,
	init = function()
		vim.cmd("colorscheme kanagawa-dragon")
	end,
	config = function()
		require("kanagawa").setup({
			transparent = false,
			colors = {
				theme = {
					all = {
						ui = {
							bg_gutter = "none",
						},
					},
				},
			},
			overrides = function(colors)
				local theme = colors.theme
				return {
					Pmenu = { fg = theme.ui.shade0, bg = theme.ui.bg_m3 },
					PmenuSel = { fg = "NONE", bg = theme.ui.bg_m2 },
					PmenuSbar = { bg = theme.ui.bg_m3 },
					PmenuThumb = { bg = theme.ui.bg_m3 },
					TelescopeTitle = { fg = theme.ui.special, bold = true },
					TelescopePromptNormal = { bg = theme.ui.bg_m3 },
					TelescopePromptBorder = { fg = theme.ui.bg_p1, bg = theme.ui.bg_m3 },
					TelescopeResultsNormal = { fg = theme.ui.fg_m3, bg = theme.ui.bg_m3 },
					TelescopeResultsBorder = { fg = theme.ui.bg_m3, bg = theme.ui.bg_m3 },
					TelescopePreviewNormal = { bg = theme.ui.bg_m3 },
					TelescopePreviewBorder = { bg = theme.ui.bg_m3, fg = theme.ui.bg_m3 },
				}
			end,
		})
	end,
}
